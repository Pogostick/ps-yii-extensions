<?php

// This is the configuration for yiic console application.
// Any writable CConsoleApplication properties can be configured here.
return array(
	'basePath' => __DIR__ . DIR_SEP . '..',

	'name' => 'My Console Application',
);