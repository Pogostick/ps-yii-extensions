<h1><?php echo $this->action->id; ?> View</h1>

<p>
This is the view content for action "<?php echo $this->action->id; ?>" of controller "<?php echo $this->id; ?>".
</p>
<p>
You may customize this view by editing the file "<?php echo __FILE__; ?>".
</p>
